java -Xms512M -Xmx4096M -DPaper.IgnoreJavaVersion=true -jar paper-1.16.5-794.jar nogui
